plugins { id("com.android.application"); id("org.jetbrains.kotlin.android") }
android {
    namespace = "com.evd.tvremote"
    compileSdk = 34
    defaultConfig { applicationId = "com.evd.tvremote"; minSdk = 24; targetSdk = 34; versionCode = 1; versionName = "1.0" }
    compileOptions { sourceCompatibility = JavaVersion.VERSION_17; targetCompatibility = JavaVersion.VERSION_17 }
    kotlinOptions { jvmTarget = "17" }
    packaging { resources { excludes += setOf("META-INF/*.SF", "META-INF/*.RSA", "META-INF/*.DSA") } }
}
dependencies {
    implementation("com.madgag.spongycastle:core:1.58.0.0")
    implementation("com.madgag.spongycastle:prov:1.58.0.0")
    implementation("com.madgag.spongycastle:pkix:1.58.0.0")
}
