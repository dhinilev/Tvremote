package com.evd.tvremote

import android.content.Context
import android.util.Base64
import org.spongycastle.asn1.x500.X500Name
import org.spongycastle.cert.jcajce.JcaX509CertificateConverter
import org.spongycastle.cert.jcajce.JcaX509v3CertificateBuilder
import org.spongycastle.operator.jcajce.JcaContentSignerBuilder
import java.io.*
import java.math.BigInteger
import java.security.*
import java.security.cert.CertificateFactory
import java.security.cert.X509Certificate
import java.security.interfaces.RSAPublicKey
import java.security.spec.PKCS8EncodedKeySpec
import java.util.Date
import java.util.concurrent.Executors
import javax.net.ssl.*

/** Minimal protobuf helpers (varint + length-delimited only). */
object Pb {
    fun varint(v: Long): ByteArray {
        val o = ByteArrayOutputStream(); var x = v
        while (true) {
            if ((x and 0x7FL.inv()) == 0L) { o.write(x.toInt()); break }
            o.write(((x and 0x7F) or 0x80).toInt()); x = x ushr 7
        }
        return o.toByteArray()
    }
    fun int(f: Int, v: Long) = varint((f shl 3).toLong()) + varint(v)
    fun bytes(f: Int, b: ByteArray) = varint(((f shl 3) or 2).toLong()) + varint(b.size.toLong()) + b
    fun str(f: Int, s: String) = bytes(f, s.toByteArray())
    fun parse(b: ByteArray): Map<Int, Any> {
        val m = HashMap<Int, Any>(); var i = 0
        fun rv(): Long {
            var r = 0L; var s = 0
            while (true) { val c = b[i++].toInt() and 0xFF; r = r or ((c and 0x7F).toLong() shl s); if ((c and 0x80) == 0) break; s += 7 }
            return r
        }
        while (i < b.size) {
            val t = rv().toInt(); val f = t shr 3
            when (t and 7) {
                0 -> m[f] = rv()
                2 -> { val l = rv().toInt(); m[f] = b.copyOfRange(i, i + l); i += l }
                1 -> i += 8
                5 -> i += 4
                else -> return m
            }
        }
        return m
    }
    fun write(o: OutputStream, msg: ByteArray) { o.write(varint(msg.size.toLong()) + msg); o.flush() }
    fun read(i: InputStream): ByteArray {
        var len = 0; var s = 0
        while (true) { val c = i.read(); if (c < 0) throw EOFException(); len = len or ((c and 0x7F) shl s); if ((c and 0x80) == 0) break; s += 7 }
        val buf = ByteArray(len); var n = 0
        while (n < len) { val r = i.read(buf, n, len - n); if (r < 0) throw EOFException(); n += r }
        return buf
    }
}

/** Self-signed client identity, generated once and kept in prefs. */
class Identity private constructor(val keyStore: KeyStore, val cert: X509Certificate) {
    companion object {
        @Synchronized fun get(ctx: Context): Identity {
            val p = ctx.getSharedPreferences("id", 0)
            val kf = KeyFactory.getInstance("RSA")
            val cf = CertificateFactory.getInstance("X.509")
            val priv: PrivateKey; val cert: X509Certificate
            val k = p.getString("key", null); val c = p.getString("cert", null)
            if (k != null && c != null) {
                priv = kf.generatePrivate(PKCS8EncodedKeySpec(Base64.decode(k, 0)))
                cert = cf.generateCertificate(ByteArrayInputStream(Base64.decode(c, 0))) as X509Certificate
            } else {
                val g = KeyPairGenerator.getInstance("RSA"); g.initialize(2048)
                val kp = g.generateKeyPair()
                val n = X500Name("CN=atvremote"); val now = System.currentTimeMillis()
                val b = JcaX509v3CertificateBuilder(n, BigInteger.valueOf(now), Date(now - 86400000L), Date(now + 3650L * 86400000L), n, kp.public)
                cert = JcaX509CertificateConverter().getCertificate(b.build(JcaContentSignerBuilder("SHA256withRSA").build(kp.private)))
                priv = kp.private
                p.edit().putString("key", Base64.encodeToString(priv.encoded, 0)).putString("cert", Base64.encodeToString(cert.encoded, 0)).apply()
            }
            val ks = KeyStore.getInstance(KeyStore.getDefaultType()); ks.load(null, null)
            ks.setKeyEntry("k", priv, CharArray(0), arrayOf(cert))
            return Identity(ks, cert)
        }
    }
    fun factory(): SSLSocketFactory {
        val kmf = KeyManagerFactory.getInstance(KeyManagerFactory.getDefaultAlgorithm()); kmf.init(keyStore, CharArray(0))
        val tm = object : X509TrustManager { // TV uses a self-signed cert; trust it (local network only)
            override fun checkClientTrusted(c: Array<X509Certificate>?, a: String?) {}
            override fun checkServerTrusted(c: Array<X509Certificate>?, a: String?) {}
            override fun getAcceptedIssuers() = arrayOf<X509Certificate>()
        }
        val ctx = SSLContext.getInstance("TLS"); ctx.init(kmf.keyManagers, arrayOf<TrustManager>(tm), null)
        return ctx.socketFactory
    }
}

/** Step 1: pair with the TV (port 6467). TV shows a 6-char hex code. */
class Pairing(private val host: String, private val id: Identity) {
    private lateinit var sock: SSLSocket
    private lateinit var inp: InputStream
    private lateinit var out: OutputStream

    private fun outer(field: Int, body: ByteArray) = Pb.int(1, 2) + Pb.int(2, 200) + Pb.bytes(field, body)
    private fun exchange(field: Int, body: ByteArray) {
        Pb.write(out, outer(field, body))
        val r = Pb.parse(Pb.read(inp))
        if (r[2] != 200L) throw IOException("TV rejected pairing (status ${r[2]})")
    }

    fun start() {
        sock = id.factory().createSocket(host, 6467) as SSLSocket
        sock.startHandshake(); inp = sock.inputStream; out = sock.outputStream
        exchange(10, Pb.str(1, "androidtv-remote") + Pb.str(2, "EV Remote"))
        val enc = Pb.int(1, 3) + Pb.int(2, 6) // HEX, 6 symbols
        exchange(20, Pb.bytes(1, enc) + Pb.int(3, 1))
        Pb.parse(Pb.read(inp)) // TV's options message
        exchange(30, Pb.bytes(1, enc) + Pb.int(2, 1))
    }

    private fun strip(b: BigInteger): ByteArray { val a = b.toByteArray(); return if (a.size > 1 && a[0].toInt() == 0) a.copyOfRange(1, a.size) else a }

    fun finish(code: String) {
        require(code.length == 6) { "Code must be 6 characters" }
        val srv = sock.session.peerCertificates[0].publicKey as RSAPublicKey
        val cli = id.cert.publicKey as RSAPublicKey
        val nonce = ByteArray(2) { code.substring(2 + it * 2, 4 + it * 2).toInt(16).toByte() }
        val md = MessageDigest.getInstance("SHA-256")
        md.update(strip(cli.modulus)); md.update(strip(cli.publicExponent))
        md.update(strip(srv.modulus)); md.update(strip(srv.publicExponent)); md.update(nonce)
        val h = md.digest()
        if (h[0] != code.substring(0, 2).toInt(16).toByte()) throw IOException("Wrong code")
        exchange(40, Pb.bytes(1, h))
        sock.close()
    }
}

/** Step 2: control the TV (port 6466). */
class TvRemote(private val host: String, private val id: Identity, private val onStatus: (String) -> Unit) {
    private lateinit var sock: SSLSocket
    private lateinit var out: OutputStream
    private val ex = Executors.newSingleThreadExecutor()
    @Volatile var open = false

    fun connect() {
        sock = id.factory().createSocket(host, 6466) as SSLSocket
        sock.startHandshake(); out = sock.outputStream
        val inp = sock.inputStream
        open = true; onStatus("Connecting…")
        Thread {
            try {
                while (true) {
                    val m = Pb.parse(Pb.read(inp))
                    when {
                        m.containsKey(1) -> {
                            val dev = Pb.str(1, "Phone") + Pb.str(2, "EV") + Pb.int(3, 1) + Pb.str(4, "1") + Pb.str(5, "androidtv-remote") + Pb.str(6, "1.0.0")
                            send(Pb.bytes(1, Pb.int(1, 622) + Pb.bytes(2, dev)))
                        }
                        m.containsKey(2) -> { send(Pb.bytes(2, Pb.int(1, 622))); onStatus("Connected ✓") }
                        m.containsKey(8) -> {
                            val v = (Pb.parse(m[8] as ByteArray)[1] as? Long) ?: 1L
                            send(Pb.bytes(9, Pb.int(1, v)))
                        }
                    }
                }
            } catch (e: Exception) { if (open) onStatus("Disconnected") } finally { open = false }
        }.start()
    }

    private fun send(m: ByteArray) {
        try { ex.execute { try { synchronized(out) { Pb.write(out, m) } } catch (_: Exception) {} } } catch (_: Exception) {}
    }

    fun key(code: Int) {
        if (!open) { onStatus("Not connected"); return }
        send(Pb.bytes(10, Pb.int(1, code.toLong()) + Pb.int(2, 3))) // SHORT press
    }

    fun close() { open = false; try { sock.close() } catch (_: Exception) {}; ex.shutdown() }
}
