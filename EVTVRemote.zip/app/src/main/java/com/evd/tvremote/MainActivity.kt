package com.evd.tvremote

import android.app.Activity
import android.app.AlertDialog
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.text.InputType
import android.view.Gravity
import android.view.HapticFeedbackConstants
import android.view.View
import android.widget.*

class MainActivity : Activity() {
    private var remote: TvRemote? = null
    private lateinit var status: TextView
    private lateinit var ip: EditText
    private val prefs by lazy { getSharedPreferences("tv", 0) }
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(14), dp(28), dp(14), dp(14)) }

        ip = EditText(this).apply {
            hint = "TV IP (e.g. 192.168.1.20)"; setText(prefs.getString("ip", ""))
            setTextColor(Color.WHITE); setHintTextColor(Color.GRAY); inputType = InputType.TYPE_CLASS_PHONE
            maxLines = 1; layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
        }
        val connectBtn = btn("Connect") { connect() }
        val pairBtn = btn("Pair") { pair() }
        root.addView(row(ip, connectBtn, pairBtn))
        status = TextView(this).apply { setTextColor(Color.LTGRAY); text = "Enter TV IP, tap Pair once, then Connect"; setPadding(dp(4), dp(4), dp(4), dp(12)) }
        root.addView(status)

        root.addView(row(key("⏻", 26, Color.rgb(200, 40, 40)), key("Input", 178), key("Settings", 176)))
        root.addView(gap())
        root.addView(row(blank(), key("▲", 19), blank()))
        root.addView(row(key("◀", 21), key("OK", 23, Color.rgb(30, 110, 200)), key("▶", 22)))
        root.addView(row(blank(), key("▼", 20), blank()))
        root.addView(gap())
        root.addView(row(key("Back", 4), key("Home", 3), key("Menu", 82)))
        root.addView(gap())
        root.addView(row(key("Vol −", 25), key("Mute", 164), key("Vol +", 24)))
        root.addView(row(key("CH −", 167), key("⏯", 85), key("CH +", 166)))

        setContentView(ScrollView(this).apply { setBackgroundColor(Color.rgb(17, 17, 17)); isFillViewport = true; addView(root) })
        if (!ip.text.isNullOrBlank()) connect()
    }

    private fun style(v: View, color: Int) {
        v.background = GradientDrawable().apply { setColor(color); cornerRadius = dp(14).toFloat() }
    }
    private fun btn(t: String, color: Int = Color.rgb(50, 50, 55), onClick: () -> Unit) = Button(this).apply {
        text = t; isAllCaps = false; setTextColor(Color.WHITE); textSize = 17f; style(this, color)
        layoutParams = LinearLayout.LayoutParams(0, dp(64), 1f).apply { setMargins(dp(4), dp(4), dp(4), dp(4)) }
        setOnClickListener { it.performHapticFeedback(HapticFeedbackConstants.KEYBOARD_TAP); onClick() }
    }
    private fun key(t: String, code: Int, color: Int = Color.rgb(50, 50, 55)) = btn(t, color) { remote?.key(code) ?: setStatus("Not connected") }
    private fun blank() = View(this).apply { layoutParams = LinearLayout.LayoutParams(0, dp(64), 1f) }
    private fun gap() = View(this).apply { layoutParams = LinearLayout.LayoutParams(1, dp(12)) }
    private fun row(vararg v: View) = LinearLayout(this).apply { gravity = Gravity.CENTER; v.forEach { addView(it) } }
    private fun setStatus(s: String) = runOnUiThread { status.text = s }

    private fun host(): String? {
        val h = ip.text.toString().trim()
        if (h.isEmpty()) { setStatus("Enter the TV's IP address"); return null }
        prefs.edit().putString("ip", h).apply(); return h
    }

    private fun connect() {
        val h = host() ?: return
        remote?.close(); setStatus("Connecting…")
        Thread {
            try { val r = TvRemote(h, Identity.get(this)) { setStatus(it) }; r.connect(); remote = r }
            catch (e: Exception) { setStatus("Connect failed: ${e.message}. Try Pair first.") }
        }.start()
    }

    private fun pair() {
        val h = host() ?: return
        setStatus("Pairing… a code will appear on the TV")
        Thread {
            try { val p = Pairing(h, Identity.get(this)); p.start(); runOnUiThread { askCode(p) } }
            catch (e: Exception) { setStatus("Pair failed: ${e.message}") }
        }.start()
    }

    private fun askCode(p: Pairing) {
        val et = EditText(this).apply { hint = "6-character code"; setPadding(dp(20), dp(16), dp(20), dp(16)) }
        AlertDialog.Builder(this).setTitle("Enter code shown on TV").setView(et).setCancelable(false)
            .setPositiveButton("Pair") { _, _ ->
                Thread {
                    try { p.finish(et.text.toString().trim()); setStatus("Paired ✓"); runOnUiThread { connect() } }
                    catch (e: Exception) { setStatus("Pair failed: ${e.message}") }
                }.start()
            }.show()
    }

    override fun onDestroy() { remote?.close(); super.onDestroy() }
}
